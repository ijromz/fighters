<?php require('actions/users/loginAction.php'); ?>
<?php require('actions/database.php'); ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'includes/head.php'; ?>
    <body>
        <main class="landingBody">
            <div class="container_home">
                <h1> Choose level</h1>
                <div class="player_name">
                    <p> Player : <?php echo $_SESSION['pseudo']; ?> </p>
                </div>
                <div class="level">
                    <a href="game/level1.html">
                        <input type="submit" class="submit" value="Level 1">  
                    </a>
                    <a href="game/level2.html">
                        <input type="submit" class="submit" value="Level 2">  
                    </a>
                    <a href="game/level3.html">
                        <input type="submit" class="submit" value="Level 3">  
                    </a>
                    <a href="game/level4.html">
                        <input type="submit" class="submit" value="Level 4">  
                    </a>
                    <a href="game/level5.html">
                        <input type="submit" class="submit" value="Level 5">  
                    </a>
                    <a href="game/level6.html">
                        <input type="submit" class="submit" value="Level 6">  
                    </a>
                    <style>
                        .level{
                            display:flex;
                            flex-wrap: wrap;
                            justify-content:space-around;
                        }
                        .level input{
                            font-size:24px;
                        }
                    </style>
                </div>
            </div>
        </main>
    </body>
</html>