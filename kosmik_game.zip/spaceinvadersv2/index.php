<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'includes/head.php'; ?>
</head>
<body>
    <main class="landingBody">
        <section class="landingSentence">  
            <span style="--i:1">WHO</span>
            <span style="--i:2">WILL</span>
            <span style="--i:3">BE</span>
            <span style="--i:4">THE</span>
            <span style="--i:5">BEST?</span>    
        </section>

        <section class="landingSectionBtn">
            <a href="login.php"><button class="landingBtn">Start</button></a>
        </section>
    </main>
</body>
</html> 